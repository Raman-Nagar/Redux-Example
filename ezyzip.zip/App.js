import logo from './logo.svg';
import './App.css';
import Todo from './components/Todo';
import Updown from './components/Updown';

function App() {
  return (
    <div className="App">
      <Todo />
    <Updown />
    </ div>
  );
}

export default App;
