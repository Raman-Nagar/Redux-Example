import { combineReducers } from "redux";
import TodoReducer from "./TodoReducer";
import IncDecReducer from "./IncDecReducer";

const rootReducer = combineReducers({
    TodoReducer,
    IncDecReducer
})
export default rootReducer;